﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace JSONGeneration
{
    public class Target
    {
        public string TargetId { get; set; }
        public int TargetValue { get; set; }        
    }
    public class TargetCollection : Dictionary<string, Target>
    {

    }



}
