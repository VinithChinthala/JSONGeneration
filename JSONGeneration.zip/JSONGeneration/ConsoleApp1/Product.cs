﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Serialization;

namespace JSONGeneration
{
    public class Product : IEquatable<Product>
    {
        [JsonPropertyName("sku")]
        public int SKU { get; set; }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("description")]
        public string Description { get; set; }
        public string Store_Id { get; set; }
        public string Department_Id { get; set; }
        public string Category_Id { get; set; }
        public string Subcategory_Id { get; set; }
        [JsonPropertyName("priceList")]
        public decimal PriceList { get; set; }
        [JsonPropertyName("taxanomy")]
        public List<string> Taxanomy { get; set; }
        [JsonPropertyName("targetValues")]
        public List<int> TargetValues { get; set; }
        public override int GetHashCode()
        {
            return SKU;
        }
        public override bool Equals(object obj)
        {
            return Equals(obj as Product);
        }
        public bool Equals(Product obj)
        {
            return obj != null && obj.SKU == this.SKU;
        }

        //Method to Build shorthand taxanomy ids
        public Product BuildTaxanomyStrings(Product product)
        {
            List<string> taxanomyStrings = new List<string> ();
            taxanomyStrings.Add("sto" + Store_Id);
            taxanomyStrings.Add("dep" + Department_Id);
            taxanomyStrings.Add("cat" + Category_Id);
            taxanomyStrings.Add("sub" + Subcategory_Id);
            product.Taxanomy = taxanomyStrings;
            return product;
        }

        //Method to Map Product Taxonomy with Target Values
        public Product FilterTargetValues(Product product, Dictionary<string, Target> targetCollection)
        {
            List<Target> targetValues = new List<Target>();
           foreach(var taxanomyStr in product.Taxanomy)
           {
                Target tgt = new Target();
                tgt.TargetId = taxanomyStr;
                tgt.TargetValue =targetCollection.Where(x => x.Key == tgt.TargetId).FirstOrDefault().Value.TargetValue;
                targetValues.Add(tgt);
           }
            product.TargetValues = targetValues.Select(x => x.TargetValue).ToList();
            return product;
        }
    }
    public class ProductCollection: Dictionary<int, Product>
    {

    }
}
