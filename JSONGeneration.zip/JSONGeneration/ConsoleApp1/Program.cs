﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace JSONGeneration
{
    public class Program
    {
        static void Main(string[] args)
        {
            var repo = new Repository();
            Dictionary<string, Target> targets = repo.GenerateTargetCollection();
            Dictionary<int, Product> products = repo.GenerateProductCollection();
            var OutputJSON = repo.ComposeJSON(products);
            Console.WriteLine("OutputJSON: " + OutputJSON);
            Console.ReadLine();
        }    
    }
}
