﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Configuration;

namespace JSONGeneration
{
    public class Repository
    {
        public static Dictionary<string, Target> targetCollection = new Dictionary<string, Target>();
        string targetsFilePath = ConfigurationManager.AppSettings["TargetsFilePath"];

        //Method to Convert Target data Text files to Collections
        public Dictionary<string, Target> GenerateTargetCollection()
        {
            string targetFileText = null;
            try
            {

                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr = new StreamReader(targetsFilePath + "targets.txt");
                //Read the first line of text
                targetFileText = sr.ReadToEnd();
                sr.Close();
                targetCollection = targetFileText.Split(new string[] { "\r\n", "\r", "\n" },
                                                  StringSplitOptions.None).Select(x => x.Split("\t")).ToDictionary(x => x[0].ToString(), x => BuildTarget(x));
               // Console.WriteLine(targetCollection.First().Key);
                //Console.ReadLine();
            }
            catch (Exception e)
            {
                //Console.WriteLine("Exception: " + e.Message);
            }
            return targetCollection;
        }
        //Method to Convert Product data Text files to Collections
        public Dictionary<int, Product> GenerateProductCollection()
        {
            Dictionary<int, Product> productCollection = new Dictionary<int, Product>();
            string productFileText = null;
            string productFileHeaderText = null;
            string productFileHeaderTextConst = ConfigurationManager.AppSettings["ProductsHeaderRecord"];
            try
            {
                //Pass the file path and file name to the StreamReader constructor
                StreamReader sr = new StreamReader(targetsFilePath + "products.txt");
                //Read the first line of text
                productFileHeaderText = sr.ReadLine();
                if (productFileHeaderText == productFileHeaderTextConst)
                {
                    productFileText = sr.ReadToEnd();
                }
                sr.Close();
                //Ignore the records with no values
                List<string> productStringList = productFileText.Split(new string[] { "\r\n", "\r", "\n" },
                                                  StringSplitOptions.None).Distinct().Where(c => c != "").ToList();
                productCollection = productStringList.ToDictionary(x => productStringList.IndexOf(x), x => BuildProduct(x));
                //Console.WriteLine(productCollection.First().Value);
                //Console.ReadLine();
            }
            catch (Exception e)
            {
               // Console.WriteLine("Exception: " + e.Message);
            }
            return productCollection;
        }

        //Method to Build Target from the string
        public Target BuildTarget(string[] trgtStrings)
        {
            Target target = new Target();
            target.TargetId = trgtStrings[0];
            target.TargetValue = Convert.ToInt32(string.IsNullOrEmpty(trgtStrings[1]) ? "0" : trgtStrings[1]);
            return target;
        }

        //Method to Build Product from the string
        public Product BuildProduct(string str)
        {
            Product product = new Product();
            try
            {
                if (!string.IsNullOrEmpty(str))
                {
                    List<string> details = str.Split("|").ToList();
                    product.SKU = Convert.ToInt32(details[0]);
                    product.Name = details[1].ToString();
                    product.Description = details[2].ToString();
                    product.Store_Id = details[3];
                    product.Department_Id = details[4];
                    product.Category_Id = details[5];
                    product.Subcategory_Id = details[6];
                    product.PriceList = Convert.ToDecimal(details[7].Remove(0, 1));
                    product.BuildTaxanomyStrings(product);
                    product.FilterTargetValues(product, targetCollection);
                }
            }
            catch (Exception e)
            {
                //Console.WriteLine("Exception: " + e.Message);
            }
            return product;

        }

        //Method to Compose JSON from the Target and Product Collections
        public string ComposeJSON(Dictionary<int, Product> products)
        {
            var serializeOptions = new JsonSerializerOptions
            {
                PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
                WriteIndented = true
            };
            string OutputJSON = JsonSerializer.Serialize(products.Select(x=> x.Value).Select(y=>new { y.SKU,y.Name,y.Description,y.PriceList,y.Taxanomy,y.TargetValues}), serializeOptions);
            File.WriteAllText(targetsFilePath + "output.txt", OutputJSON);
            return OutputJSON;
        }
    }
}
